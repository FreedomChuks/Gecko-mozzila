# Simple Browser
## Step 4 Navigation buttons.

Simple Browser to illustrate this [blog post](https://medium.com/p/562250a2291a/)

<img src="images/navigation-actions.gif" height="600em" />